// importar a classe fornecedor 
import Fornecedor  from "./fornecedor.js";

//criando a classe
class FornecedorPessoa extends Fornecedor{
    #rg;
    #cpf;
    //criando constructor

    constructor(nome = "sem nome", fone = "(00) 0000-0000", rg = " ", cpf = " "){
        super(nome, fone);
        this.#rg = rg;
        this.#cpf = cpf;
    }

    // criando setters
    setRg (rg){
        this.#rg = rg;
    }

    setCPF (cpf){
        this.#cpf = cpf;
    }

    //criando getters
    getRG(){
        return this.#rg;
    }

    getCPF(){
        return this.#cpf;
    }
}

export default FornecedorPessoa;