//importando classes
import Fornecedor from "./fornecedor";
import FornecedorPessoa from "./fornecedor_pessoa";

//criar e instanciar o objeto no método construtor da classe fornecedor

const objfornecedor = new Fornecedor("pedro henrique", "(11) 97825-3654");

console.log (`Dados do fornecedor:
    Nome: ${objfornecedor.getNome()}
    telefone: ${objfornecedor.getFone()}`);

const objFornecedorPessoa = new FornecedorPessoa("marina silva", "(11) 98424-8065", "12.123.456-7", "222.170.568.83")

console.log (`Dados do fornecedor pessoa:
    Nome: ${objFornecedorPessoa.getNome()}
    fone: ${objFornecedorPessoa.getFone()}
    Rg: ${objFornecedorPessoa.getRG()}
    CPF: ${objFornecedorPessoa.getCPF()}`);